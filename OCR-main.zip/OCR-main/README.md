# Reconocimiento Óptico de Caracteres
